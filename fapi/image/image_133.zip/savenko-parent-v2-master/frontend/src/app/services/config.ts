export enum Config {
  LOCALHOST = "localhost",
  PORT = '8083',
  POSTFIX = "/api/files/"
}
