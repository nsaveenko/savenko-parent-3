export class ErrorModel{
  public field:string;
  public defaultMessage:string;
  public code:number;
  public rejectedValue:string;

  constructor(){}
}
