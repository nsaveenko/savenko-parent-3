import {User} from "./User";

export class SignIn {
  error: string;
  user: User;
  token: string;
}
