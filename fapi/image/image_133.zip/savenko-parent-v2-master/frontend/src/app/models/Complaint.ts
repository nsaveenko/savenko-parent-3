export class Complaint {
  id:number;
  idUser: number;
  dateComplaint: number;
  complaint: string;
  idPost: number;
  idStatusComplaint: number;
}
