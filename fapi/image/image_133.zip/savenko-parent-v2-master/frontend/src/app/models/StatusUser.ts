export class StatusUser {
  id: number;
  status: string;
}
